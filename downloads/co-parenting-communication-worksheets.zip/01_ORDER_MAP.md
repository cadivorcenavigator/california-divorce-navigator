# Worksheet 1 — Order Map

**Use:** Translate the governing order or agreement into operational rules. Complete with counsel where interpretation is uncertain.

| Topic | Exact provision | Who decides? | Notice required | Response time | Silence means | Exceptions | Proof/source |
|---|---|---|---|---|---|---|---|
| Communication channel |  |  |  |  |  |  |  |
| Emergency |  |  |  |  |  |  |  |
| Medical |  |  |  |  |  |  |  |
| Education |  |  |  |  |  |  |  |
| Therapy |  |  |  |  |  |  |  |
| Activities |  |  |  |  |  |  |  |
| Schedule changes |  |  |  |  |  |  |  |
| Travel |  |  |  |  |  |  |  |
| Expenses |  |  |  |  |  |  |  |

## Rule hierarchy for this family

1. Safety/emergency: ______________________________________________
2. Express shared-decision rules: __________________________________
3. Express schedule/notice rules: __________________________________
4. Day-to-day discretion: __________________________________________
5. Courtesy/preferences: ___________________________________________

## Interpretation questions for counsel

____________________________________________________________________

