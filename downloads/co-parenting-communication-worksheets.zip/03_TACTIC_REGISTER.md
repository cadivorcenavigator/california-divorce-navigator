# Worksheet 3 — Observable Pattern Register

Use neutral descriptions. A row records an event for later pattern review; it is not a diagnosis or legal conclusion.

| Date/thread | Operative request | Provision | Observable feature | Response | Outcome | Corroboration | Materiality |
|---|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |

**Permitted feature labels:** bundling; scope expansion; relevance dilution; assumed consent; routine elevation; repeat deadline; premature action; third-party leverage; unclear request; unsupported obligation.

**Do not enter:** personality diagnoses, speculation about intent, insults, or conclusions such as “violation” unless supplied by qualified counsel or a court.

