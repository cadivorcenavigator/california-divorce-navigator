# Worksheet 2 — Break Down a Difficult Message

**Use this when:** A message is long, upsetting, or mixes several issues together.

**Message/date:** ____________________  **Real deadline, if any:** __________

## What are they actually asking me to decide or do?

____________________________________________________________________

| Part of the message | Answer / Check / Leave out / Handle separately | My answer or next step | Fact or order wording I need |
|---|---|---|---|
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |

**What I will not debate in this reply:** _____________________________

**The one next step that matters:** __________________________________

