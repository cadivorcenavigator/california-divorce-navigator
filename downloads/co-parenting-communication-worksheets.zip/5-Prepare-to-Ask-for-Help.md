# Worksheet 5 — Prepare to Ask a Professional for Help

**Use this when:** A repeated or serious problem may need help from a lawyer, coach, mediator, parenting coordinator, or other professional.

**The problem in one sentence:** ____________________________________

## Is this important enough to raise now?

| Question | Low / Medium / High | Notes |
|---|---|---|
| Could this affect my child, schedule, rights, safety, or significant money? |  |  |
| Has it happened more than once? |  |  |
| Do I have clear written proof? |  |  |
| Is there a real deadline? |  |  |
| Is there something a professional could realistically help solve? |  |  |

## What does the order say?

Exact wording or page number: _______________________________________

## The three clearest examples

1. Date, what was asked, my answer, and what happened: ______________
2. Date, what was asked, my answer, and what happened: ______________
3. Date, what was asked, my answer, and what happened: ______________

## Records that support this

____________________________________________________________________

## What I do not know or cannot prove

____________________________________________________________________

## The exact question I want the professional to answer

____________________________________________________________________

