# Worksheet 4 — Closed Response Builder

1. **Receipt, if needed:** `I received ______________________________.`
2. **Operative request:** `Regarding the request to __________________.`
3. **Disposition:** AGREE / DO NOT AGREE / NEED INFORMATION / WILL COMPLY / NOT APPLICABLE
4. **One necessary fact or rule:** ___________________________________
5. **Next action:** _________________________________________________
6. **Boundary, if needed:** _________________________________________

## Draft

____________________________________________________________________

____________________________________________________________________

## Stop-rule edit

- [ ] Every operative request has a disposition.
- [ ] Consent or non-consent is explicit.
- [ ] I removed motive claims and character defense.
- [ ] I removed unrelated history.
- [ ] The external or order-based deadline is accurate.
- [ ] The response closes rather than opens new subjects.

**Final word count:** ______  **Paragraphs removed:** ______

