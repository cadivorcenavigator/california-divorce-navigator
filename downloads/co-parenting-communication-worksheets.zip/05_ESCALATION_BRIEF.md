# Worksheet 5 — Escalation Brief

**Issue:** __________________________________________________________

## Why this issue merits review

| Test | Score 0–3 | Notes |
|---|---:|---|
| Consequence to child, rights, money, or schedule |  |  |
| Recurrence |  |  |
| Strength of documentary proof |  |  |
| Time sensitivity |  |  |
| Availability of a practical remedy |  |  |

**Total:** ____ / 15

## Governing provision

Exact text/reference: _______________________________________________

## Three strongest events

1. Date/thread, conduct, disposition, outcome: _______________________
2. Date/thread, conduct, disposition, outcome: _______________________
3. Date/thread, conduct, disposition, outcome: _______________________

## Corroborating material

____________________________________________________________________

## What the record does not establish

____________________________________________________________________

## Specific question or requested remedy

____________________________________________________________________

