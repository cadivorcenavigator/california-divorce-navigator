# Worksheet 2 — Thread Decomposition

**Thread/date:** ____________________  **Response due:** ______________

**Smallest concrete decision:** _____________________________________

| # | Message component | Answer / Verify / Ignore / Separate | Disposition or action | Supporting fact/provision |
|---|---|---|---|---|
| 1 |  |  |  |  |
| 2 |  |  |  |  |
| 3 |  |  |  |  |
| 4 |  |  |  |  |
| 5 |  |  |  |  |

**Communication style:** Collaborative / Directive / Conflated / Procedural / Mixed

**One necessary boundary:** _________________________________________

**What I will deliberately not answer:** _____________________________

