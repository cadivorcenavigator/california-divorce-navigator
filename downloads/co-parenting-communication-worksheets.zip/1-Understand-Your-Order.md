# Worksheet 1 — Understand What Your Order Says

**Use this when:** You are unsure who decides, whether you must answer, or what happens if someone stays silent.

Copy the exact wording from your court order or written agreement. Ask your lawyer when the meaning is unclear.

| Topic | Where is it in the order? | Who decides? | How much notice? | When must I answer? | What happens if no one answers? | Important exceptions |
|---|---|---|---|---|---|---|
| Emergencies |  |  |  |  |  |  |
| Medical care |  |  |  |  |  |  |
| School |  |  |  |  |  |  |
| Therapy |  |  |  |  |  |  |
| Activities |  |  |  |  |  |  |
| Schedule changes |  |  |  |  |  |  |
| Travel |  |  |  |  |  |  |
| Expenses |  |  |  |  |  |  |
| Co-parenting messages |  |  |  |  |  |  |

## Questions I need to ask my lawyer

____________________________________________________________________

____________________________________________________________________

