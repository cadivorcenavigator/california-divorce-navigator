# Worksheet 3 — Message Pattern Log

**Use this when:** The same communication problem keeps happening and may become important.

Write only what you can point to in the message or records. Do not guess about personality or motives.

| Date/message | What was the actual question? | What made the message hard to answer? | What did I answer? | What happened next? | Supporting record | Why does this matter? |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |

## Plain-language pattern examples

- Several separate decisions mixed into one message
- Old arguments or accusations placed around the real question
- A new issue added after the conversation started
- Claiming that silence means yes
- Calling a routine matter urgent
- Repeating the same deadline after it was already answered
- Announcing an action before both parents agreed
- Saying a child or provider has already decided the issue

