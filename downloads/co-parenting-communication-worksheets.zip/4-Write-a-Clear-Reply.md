# Worksheet 4 — Write a Clear Reply

**Use this when:** You know what the real question is and need to write a short answer.

1. **The question I am answering:** _________________________________
2. **My clear answer:** YES / NO / I NEED MORE INFORMATION / I WILL DO THIS / NO QUESTION TO ANSWER
3. **One fact or reason that must be included:** _____________________
4. **What happens next:** ___________________________________________
5. **One boundary, if needed:** _____________________________________

## My draft

____________________________________________________________________

____________________________________________________________________

## Before I send it

- [ ] My answer is obvious.
- [ ] I answered every real question.
- [ ] I removed blame and guesses about motives.
- [ ] I removed old history that does not change this decision.
- [ ] I checked the actual deadline.
- [ ] The next step is clear.
- [ ] I can delete one more sentence without losing anything important.

